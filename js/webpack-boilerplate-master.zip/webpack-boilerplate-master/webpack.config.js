module.exports = {
  entry: "./src/browser.js",
  output: {
    filename: "build/application.js"
  },
  devtool: "sourcemap"
};
